package com.cg.Client;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

import org.junit.Test;

public class CommunicationTest { 

   @Test
    public void testHelloRequestCorrect() throws Exception {
        String res = Client.postRequest("Hello");
        assert (res.equals("Hello stranger!"));
    }

    @Test
    public void testHelloRequestIncorrect() throws Exception {
        String res = Client.postRequest("hello");
        assert (res.equals("Error! No or invalid request name specified! (hello)"));
    }

    @Test
    public void testTableRandomValue() throws Exception {
    	
    	HashMap<Integer, Integer> mapValues = new HashMap<Integer, Integer>();
    	//hashmap containing the values with the number of times returned
    	
    	int numberOfCalls = 100000; //we are runnung this test 100k times
    	for(int i=0; i<numberOfCalls; i++) {
    		String string = Client.postRequest("table");
            Integer result = Integer.valueOf(string);
    		
    		if(mapValues.containsKey(result)) {
    			Integer cont = mapValues.get(result);
    			cont++;
    			mapValues.replace(result, cont);
    		} else {
    			mapValues.put(result, 1);
    		}
    	}
    	
    	
    	
    	Iterator<Entry<Integer, Integer>> it = mapValues.entrySet().iterator();
        while (it.hasNext()) {
        	Entry<Integer, Integer> next = it.next();
        	System.out.print("Value:" + next.getKey() + "; ");
        	System.out.print("returned: " + next.getValue() + " times; ");
        	double percentage = (double) ((double) next.getValue() / (double) numberOfCalls) * 100;
        	System.out.print("percentage: " + percentage + "%\n");
        	
        	
        	//the margin of error with 100k test is 0.004
            // value 1 has 20% chance
            // value 2 has 25% chance
            // value 3 has 55% chance
            
            //double marginOfError = 0.04;
            double marginOfError = 1.29;
            
        	switch (next.getKey()) {
			case 1:
				assert((20 - marginOfError) < percentage &&  percentage < (20 + marginOfError)); 
				break;
			case 2:
				assert((25 - marginOfError) < percentage &&  percentage < (25 + marginOfError)); 
				break;
			case 3:
				assert((55 - marginOfError) < percentage &&  percentage < (55 + marginOfError)); 
				break;
			}
        	
        }
        
        
        
        
        
    }
    
    //add more tests here to validate your work
}
