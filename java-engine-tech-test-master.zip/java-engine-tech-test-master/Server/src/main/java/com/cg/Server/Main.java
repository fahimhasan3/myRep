package com.cg.Server;

import static spark.Spark.*;

import java.util.ArrayList;
import java.util.Random;

import org.junit.Test;

import com.cg.Server.ValueProbability;

public class Main {
    public static void main(String[] args) {
        serve();
    }

    public static void serve() {
        port(8008);
        post("/serve", (req, res) -> {
                switch(req.body()) {
                    case "Hello":
                        return hello();
                    //other scenarios could go here ;)
                    case "table":
                    	return returnRandomValue();
                    default:
                        return "Error! No or invalid request name specified! (" + req.body() + ")";
                }
            }
        );
    }

    public static String hello() {
        return "Hello stranger!";
    }
    
    public static Integer returnRandomValue () {
    	ArrayList<Integer> generateBasicWeightTable = generateBasicWeightTable();
    	int size = generateBasicWeightTable.size();
    	
    	Random rand = new Random();   
        // Generate random integer in range 0 to size of arrayList
        int randInt = rand.nextInt(size); 
        Integer randomValue = generateBasicWeightTable.get(randInt);
        
        return randomValue;
    }
    
    
    public static ArrayList<Integer> generateBasicWeightTable() {
    	
    	ArrayList<ValueProbability> values = new ArrayList<ValueProbability>();// values to be randomly generated
    	
    	
    	ValueProbability firstValue = new ValueProbability();
    	firstValue.setValue(1);
    	firstValue.setProbability(20); // value 1 has 20% chance
    	values.add(firstValue);
    	
    	ValueProbability secondValue = new ValueProbability();
    	secondValue.setValue(2);
    	secondValue.setProbability(25); // value 2 has 25% chance
    	values.add(secondValue);
    	
    	ValueProbability thirdValue = new ValueProbability();
    	thirdValue.setValue(3);
    	thirdValue.setProbability(55); // value 3 has 55% chance
    	values.add(thirdValue);
    	
    	ArrayList<Integer> basicWeightTable = new ArrayList<Integer>();
    	
    	for (ValueProbability currentValue : values) {
			int value = currentValue.getValue();
			int probability = currentValue.getProbability();
			for(int i = 0; i < probability; i++) {
				basicWeightTable.add(value);
			}
		}
    	
    	return basicWeightTable;
    	
    }
    
    @Test
    public void testHelloRequestCorrect() throws Exception {
    	generateBasicWeightTable();
    }
}
