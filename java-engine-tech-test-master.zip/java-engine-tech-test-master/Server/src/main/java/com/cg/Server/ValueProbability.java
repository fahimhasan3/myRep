package com.cg.Server;

public class ValueProbability {
	
	private int value;
	private int probability; //set as an integer so 20% would be 20
	
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public int getProbability() {
		return probability;
	}
	public void setProbability(int probability) {
		this.probability = probability;
	}
	
}
